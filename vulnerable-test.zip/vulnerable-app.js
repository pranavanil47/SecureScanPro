const password = "hardcoded123";
function login(user) {
  if (user.password === password) {
    return "authenticated";
  }
}
eval(user_input);
